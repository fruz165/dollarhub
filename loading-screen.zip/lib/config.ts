export const API_CONFIG = {
  BASE_URL: "https://dollarhub.com/api",
  ENDPOINTS: {
    CONNECT: "/connect",
    STATUS: "/status",
    TOKENS: "/tokens",
    TOKENS_REVOKE: "/tokens/revoke",
  },
  TIMEOUT: 10000, // 10 seconds
} as const

export const APP_CONFIG = {
  NAME: "Dollar Hub Client",
  VERSION: "1.0.0",
  DESCRIPTION: "Connect to Dollar Hub API services",
} as const
