import type { NextRequest } from "next/server"
import crypto from "crypto"

export interface ApiToken {
  id: string
  token: string
  name: string
  createdAt: string
  lastUsed?: string
  isActive: boolean
}

// In-memory storage for demo (use database in production)
const tokens: Map<string, ApiToken> = new Map()

export function generateApiToken(name: string): ApiToken {
  const tokenId = crypto.randomUUID()
  const token = `bd_${crypto.randomBytes(32).toString("hex")}`

  const apiToken: ApiToken = {
    id: tokenId,
    token,
    name,
    createdAt: new Date().toISOString(),
    isActive: true,
  }

  tokens.set(token, apiToken)
  return apiToken
}

export function validateApiToken(token: string): ApiToken | null {
  const apiToken = tokens.get(token)

  if (!apiToken || !apiToken.isActive) {
    return null
  }

  // Update last used timestamp
  apiToken.lastUsed = new Date().toISOString()
  tokens.set(token, apiToken)

  return apiToken
}

export function getAuthToken(request: NextRequest): string | null {
  const authHeader = request.headers.get("authorization")

  if (!authHeader) {
    return null
  }

  if (authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7)
  }

  return authHeader
}

export function getAllTokens(): ApiToken[] {
  return Array.from(tokens.values())
}

export function revokeToken(token: string): boolean {
  const apiToken = tokens.get(token)
  if (apiToken) {
    apiToken.isActive = false
    tokens.set(token, apiToken)
    return true
  }
  return false
}

// Initialize with a demo token
generateApiToken("Demo Token")
