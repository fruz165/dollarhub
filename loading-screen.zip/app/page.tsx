"use client"

import Component from "../loading-screen"

export default function Page() {
  return <Component />
}
