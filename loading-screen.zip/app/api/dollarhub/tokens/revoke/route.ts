import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()

    if (!token) {
      return NextResponse.json({ success: false, error: "Token is required" }, { status: 400 })
    }

    // Try external API first
    try {
      const response = await fetch("https://dollarhub.com/api/tokens/revoke", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
        signal: AbortSignal.timeout(5000),
      })

      if (response.ok) {
        const data = await response.json()
        return NextResponse.json(data)
      }
    } catch (externalError) {
      console.log("External Dollar Hub revoke token API unavailable, using fallback")
    }

    // Fallback - simulate token revocation
    return NextResponse.json({
      success: true,
      message: "Token revoked successfully",
      source: "fallback",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to revoke token" }, { status: 500 })
  }
}
