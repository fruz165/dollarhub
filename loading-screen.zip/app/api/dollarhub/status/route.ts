import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Try external API first
    try {
      const response = await fetch("https://dollarhub.com/api/status", {
        signal: AbortSignal.timeout(3000),
      })

      if (response.ok) {
        const data = await response.json()
        return NextResponse.json(data)
      }
    } catch (externalError) {
      console.log("External Dollar Hub status API unavailable, using fallback")
    }

    // Fallback response
    const authHeader = request.headers.get("authorization")
    let authenticatedUser = null

    if (authHeader) {
      authenticatedUser = "Demo User"
    }

    return NextResponse.json({
      service: "Dollar Hub",
      version: "1.0.0",
      status: "operational",
      uptime: "99.9%",
      lastCheck: new Date().toISOString(),
      authenticated: !!authenticatedUser,
      user: authenticatedUser,
      source: "fallback",
      services: {
        database: "online",
        api: "online",
        cdn: "online",
      },
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get status",
      },
      { status: 500 },
    )
  }
}
