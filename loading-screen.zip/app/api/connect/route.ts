import { type NextRequest, NextResponse } from "next/server"
import { getAuthToken, validateApiToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    // Check for API token
    const token = getAuthToken(request)

    if (!token) {
      return NextResponse.json({ success: false, error: "API token required" }, { status: 401 })
    }

    const validToken = validateApiToken(token)

    if (!validToken) {
      return NextResponse.json({ success: false, error: "Invalid or expired API token" }, { status: 401 })
    }

    // Simulate server connection delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simulate occasional connection failures for realism
    if (Math.random() < 0.1) {
      throw new Error("Connection failed")
    }

    return NextResponse.json({
      success: true,
      message: "Connected to Binary Dollar server successfully",
      timestamp: new Date().toISOString(),
      serverStatus: "online",
      authenticatedAs: validToken.name,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Failed to connect to server",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
