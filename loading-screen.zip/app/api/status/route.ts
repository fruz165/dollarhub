import { type NextRequest, NextResponse } from "next/server"
import { getAuthToken, validateApiToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  const token = getAuthToken(request)
  let authenticatedUser = null

  if (token) {
    const validToken = validateApiToken(token)
    if (validToken) {
      authenticatedUser = validToken.name
    }
  }

  return NextResponse.json({
    service: "Binary Dollar",
    version: "1.0.0",
    status: "operational",
    uptime: "99.9%",
    lastCheck: new Date().toISOString(),
    authenticated: !!authenticatedUser,
    user: authenticatedUser,
    services: {
      database: "online",
      api: "online",
      cdn: "online",
    },
  })
}
