import { type NextRequest, NextResponse } from "next/server"
import { revokeToken } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()

    if (!token) {
      return NextResponse.json({ success: false, error: "Token is required" }, { status: 400 })
    }

    const revoked = revokeToken(token)

    if (revoked) {
      return NextResponse.json({
        success: true,
        message: "Token revoked successfully",
      })
    } else {
      return NextResponse.json({ success: false, error: "Token not found" }, { status: 404 })
    }
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to revoke token" }, { status: 500 })
  }
}
