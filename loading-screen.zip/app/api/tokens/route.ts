import { type NextRequest, NextResponse } from "next/server"
import { generateApiToken, getAllTokens } from "@/lib/auth"

export async function GET() {
  try {
    const tokens = getAllTokens()
    return NextResponse.json({
      success: true,
      tokens: tokens.map((token) => ({
        ...token,
        token: `${token.token.substring(0, 8)}...${token.token.substring(token.token.length - 4)}`,
      })),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch tokens" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name } = await request.json()

    if (!name || typeof name !== "string") {
      return NextResponse.json({ success: false, error: "Token name is required" }, { status: 400 })
    }

    const token = generateApiToken(name)

    return NextResponse.json({
      success: true,
      message: "API token created successfully",
      token,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to create token" }, { status: 500 })
  }
}
